To run the unit tests, ensure that an installed version of islplotlib is in
your PYTHONPATH variable. Then run the following command in this directory:

python3 -m unittest *.py


